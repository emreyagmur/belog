<script src="<?=base_url("assets")?>/assets/vendor/jquery/jquery.min.js"></script>
<script src="<?=base_url("assets")?>/assets/vendor/jquery/jquery.jscroll.min.js"></script>
<script src="<?=base_url("assets")?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){

    $('[data-toggle="tooltip"]').tooltip();
    
});

</script>