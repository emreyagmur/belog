<link href="<?=base_url("assets")?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?=base_url("assets")?>/assets/vendor/fontawesome-free/css/all.min.css">
<link href="<?=base_url("assets")?>/assets/css/blog-home.css?v=<?=time()?>" rel="stylesheet">

        
