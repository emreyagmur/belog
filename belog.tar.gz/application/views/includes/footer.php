  <!-- Footer 
  <footer class="py-5 bg-dark page-footer">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
  </footer>-->
<div class="orta footer hidden mobile-display">  
    <div class="page-footer">
        <a class="text-secondary" href="<?=base_url("home_page")?>"><span><i class="fa fa-fw fa-home"></i></span></a>
        <a class="text-secondary" href="#"><span><i class="fa fa-fw fa-search"></i></span></a>
        <a class="text-secondary" href="#"><span><i class="fa fa-fw fa-heart"></i></span></a>
        <a class="text-secondary" href="<?=base_url("my_account")?>"><span><i class="fa fa-fw fa-user"></i></span></a>
    </div>
</div>
